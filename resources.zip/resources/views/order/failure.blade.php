@extends('layout_order.dashboard')
@section('content')
<h1><?php echo $data['message']; ?></h1>
<h2><?php echo $data['message1']; ?></h2>	

@endsection;


