<div class="_1VD0UF">
  <div class="_1b9jby row">
    <div class="_2c2GON">
      <div>
        <div class="_1GRhLX -yAF57 row"><img class="fUkK-z" height="50px" width="50px" src="images/man.jpg">
          <div class="M6fKa7">
            <div class="e1sGxS">
              <div class="_2T2Tfl">Hello</div>
            </div>
            </div>
          </div>
          <div class="_1GRhLX _1DGSPv">
            <div>
              <div class="_2ACZMj">
                <div class="_3NNJZh row">
                  <img class="_1xt1eX" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDI0IDE4Ij48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC04LjY5NCAtMTEpIj48ZWxsaXBzZSBjeD0iMjAuNTU3IiBjeT0iMjAiIHJ4PSIyMC41NTciIHJ5PSIyMCIvPjxwYXRoIGZpbGw9IiMyODc0RjEiIGQ9Ik05IDExdjE3LjEwOGMwIC40OTMuNDEuODkyLjkxOC44OTJoNC45M3YtNS4yNTdoLTMuMDMzbDQuOTEyLTQuNzcgNC45NzIgNC44M2gtMy4wMzVWMjloMTIuNDE3Yy41MDcgMCAuOTE4LS40LjkxOC0uODkyVjExSDl6Ii8+PC9nPjwvc3ZnPg=="><a class="_2ZZi8V" href="/account/orders">MY ORDERS<span class="_16k-VF"><svg width="16" height="27" viewBox="0 0 16 27" xmlns="http://www.w3.org/2000/svg" class="_13rI_R"><path d="M16 23.207L6.11 13.161 16 3.093 12.955 0 0 13.161l12.955 13.161z" fill="#878787" class=""></path></svg></span></a>
                </div>
              </div>
              <div class="_1zr6a1">
              </div>
            </div>
            <div>
              <div class="_2ACZMj">
                <div class="_3NNJZh row">
                  <img class="_1xt1eX" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyMiIgaGVpZ2h0PSIyMSIgdmlld0JveD0iMCAwIDIyIDIxIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKC05LjY5NCAtMTApIj48cGF0aCBmaWxsPSIjMjg3NEYwIiBkPSJNMTQuMjc1IDIyLjcwNGMyLjI3Mi0uNDEyIDQuMzQ3LS42MTggNi4yMjUtLjYxOCAxLjg3OCAwIDMuOTUzLjIwNiA2LjIyNS42MThhNS4xNSA1LjE1IDAgMCAxIDQuMjMgNS4wNjhWMzFoLTIwLjkxdi0zLjIyOGE1LjE1IDUuMTUgMCAwIDEgNC4yMy01LjA2OHptMS4yNzQtNy43MjRjMC0yLjU4IDIuMTYzLTQuNjczIDQuODMyLTQuNjczIDIuNjY3IDAgNC44MyAyLjA5MiA0LjgzIDQuNjczIDAgMi41OC0yLjE2MyA0LjY3My00LjgzIDQuNjczLTIuNjcgMC00LjgzMy0yLjA5Mi00LjgzMy00LjY3M3oiLz48ZWxsaXBzZSBjeD0iMjAuNTU3IiBjeT0iMjAiIHJ4PSIyMC41NTciIHJ5PSIyMCIvPjwvZz48L3N2Zz4="><div class="_3X41hQ">ACCOUNT SETTINGS</div>
              </div>
              <div>
              	<a href="<?php echo url('myprofile?id='.$data1->phone) ?>">
                  <div class="NqIFxw HDbIt8">Profile Information</div></a>
                  <a href="<?php echo url('address_manage?id='.$data1->phone) ?>">
                  	<div class="NqIFxw">Manage Addresses</div>
                  </a>
                  
                  </div>

                </div><div class="_1zr6a1">
              </div>
            </div>
            <div>
              
                    <div class="_1zr6a1"></div>
                  </div>
                   
                <div class="_1zr6a1">
                </div>
                <div class="_2ACZMj">
                  <div class="_3NNJZh row">
                    <svg width="24" height="24" class="" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path fill="#2874F0" stroke-width="0.3" stroke="#2874F0" d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z"></path>
                    </svg>
                    <span class="_2ZZi8V"><a href="<?php echo url('logout') ?>">Logout</a></span>
                    </div>
                  </div>
                </div>
                <div class="_1GRhLX _367yRc">
                
                  <div class="row">
                    <span class="AXbOF3"><a href="<?php echo url('change_password?id='.$data1->phone) ?>">Change Password</a></span>
                    <!-- <a class="AXbOF3" href="/account/orders">Track Order</a>
                    <a class="AXbOF3" href="/helpcentre">Help Center</a> -->
                  </div>
                </div>
              </div>
            </div>