  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        
        <div class="pull-left info">
          
        </div>
      </div>
      <!-- search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="active" id="home">
          <a href="<?php echo url('/'.'home') ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
         </li>
     
     <li class="active"><a href="<?php echo url('/'.'change_password') ?>"><i class="fa fa-circle-o"></i> Change Password</a></li>
     
        <li class="active treeview">  
         
     <a href="aaa">
            <i class="fa fa-th"></i> <span>Product Category</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>      
          <ul class="treeview-menu">
            <li class="active"><a href="<?php echo url('/'.'category') ?>"><i class="fa fa-circle-o"></i>Category</a></li>
            <li class="active"><a href="<?php echo url('/'.'sub_category') ?>"><i class="fa fa-circle-o"></i>Sub Category</a></li>
          </ul>
         
          
          
        </li> 

        <li class="active" id="home"><a href="<?php echo url('/'.'brand') ?>"><i class="fa fa-circle-o"></i>Brand</a></li> 

          <li class="active" id="home"><a href="<?php echo url('/'.'item') ?>"><i class="fa fa-circle-o"></i>Item Add</a></li>

          <li class="active" id="home"><a href="<?php echo url('/'.'location') ?>"><i class="fa fa-circle-o"></i>Location</a></li>       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  