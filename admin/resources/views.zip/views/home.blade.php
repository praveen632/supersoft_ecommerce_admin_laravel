@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="col-md-8 col-md-offset-1">
            <div>
                <div class="panel-heading" style="padding-top: 30%; padding-left: 40%">
                <h3><strong>Welcome to Supersoft</strong></h3>
                </div>
            </div>
    </section>

   
    <!-- /.content -->

@endsection
